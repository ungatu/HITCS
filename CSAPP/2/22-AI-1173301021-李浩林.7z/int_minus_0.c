#include <stdio.h>
int main(void)
{    
	int n = 2;
	n=n/0.00000000000000001;
	printf("%d",n);
	return 0;
}
  
