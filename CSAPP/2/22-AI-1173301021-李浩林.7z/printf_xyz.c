#include <stdio.h>
#include <string.h>

char cstr[100] = "1173301021-李浩林";

int main(int argc, char *argv[]){

	char *pstr = "1173301021-李浩林";
	strcpy();
	return 0;
}
